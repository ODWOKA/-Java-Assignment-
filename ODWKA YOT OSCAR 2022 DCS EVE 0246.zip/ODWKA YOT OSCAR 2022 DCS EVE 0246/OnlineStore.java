import java.util.Scanner;

public class OnlineStore {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Set the minimum age for purchasing items
        int minimumAge = 16;

        System.out.println("Welcome to the Online Store!");
        System.out.print("Enter your age: ");
        
        // Read customer's age input
        int customerAge = scanner.nextInt();

        System.out.print("Enter the age rating of the item: ");
        
        // Read item's age rating input
        int itemAgeRating = scanner.nextInt();

        // Check if the customer meets the age requirement for the item
        if (customerAge >= minimumAge && customerAge <= itemAgeRating) {
            System.out.println("Congratulations! You can purchase the item.");
        } else {
            System.out.println("Sorry, you are not eligible to purchase the item due to age restrictions.");
        }

        scanner.close();
    }
}

