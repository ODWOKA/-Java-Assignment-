import java.util.Scanner;

public class VideoGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Video Game!");
        System.out.print("Enter your player progress (1-3): ");

        
        // Read player progress input
        int playerProgress = scanner.nextInt();

        // Determine the next level based on player progress
        if (playerProgress == 1) {
            System.out.println("Loading Level 2...");
        } else if (playerProgress == 2) {
            System.out.println("Loading Level 3...");
        } else if (playerProgress == 3) {
            System.out.println("Congratulations! You've completed the game!");
        } else {
            System.out.println("Invalid progress. Please enter a number between 1 and 3.");
        }

        scanner.close();
    }
}





