import java.util.Scanner;

public class ATM {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Set the minimum balance required for withdrawal
        double minimumBalance = 5000.0;

        System.out.println("Welcome to the banking system!");
        System.out.print("Enter your account balance: $");

        // Read account balance input
        double accountBalance = scanner.nextDouble();

        // Check if the account balance is sufficient for withdrawal
        if (accountBalance >= minimumBalance) {
            System.out.println(" How much would you like to withdraw?");
            double withdrawalAmount = scanner.nextDouble();
            
            // Check if the withdrawal amount is valid
            if (withdrawalAmount <= accountBalance) {
                System.out.println("Transaction successful. Please take your money.");
            } else {
                System.out.println("Insufficient balance for withdrawal.");
            }
            
        } else {
            System.out.println("Sorry, your account balance is below the minimum required for withdrawal.");
        }

        scanner.close();
    }
}
